import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-drinker-details',
  templateUrl: './drinker-details.component.html',
  styleUrls: ['./drinker-details.component.css']
})
export class DrinkerDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
